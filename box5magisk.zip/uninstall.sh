#!/system/bin/sh

rm -f /data/adb/service.d/box5_service.sh
